<div id="purchase" class="">
  <div class="succees-mess text-center timmer">
  <h3 class="bonus-h-custom"> User Accounts </h3>
  </div>
</div>
<!--inner block start here-->
<div class="card">
  <div class="card-body">
    <div class="row">
      <div class="col-md-12">
        <div class="table-responsive">
          <table id="" class="display" width="100%" cellspacing="0">
              <thead>
                  <tr>
                    <th>Sr.</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>ETH Value</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
              </thead>
               <tbody>
                <?php
                $counter = 1;
                if(!empty($funds)){
                foreach ($funds as $fund) {
                  // echo "<pre>";
                  // var_dump($fund);exit();
                ?>
                 <tr>
                    <td><?= $counter ?></td>
                    <td><?= $fund['u_name'] ?></td>
                    <td><?= $fund['u_email'] ?></td>
                    <td><?= $fund['ph_other_coin'] ?></td>
                    <td><?= $fund['ph_date'] ?></td>
                    <td>                       

                          <a title="Approve Payment" class="btn btn-xs btn-primary btn-primaryc" href="<?= base_url()?>admin/funds_approval/<?= $fund['ph_id'] ?>">  &nbsp; &nbsp;Approve &nbsp; </a>
                      </td>
                  </tr>
                  <?php 
                  $counter++;
                    }
                  }//if
                  else
                  {
                    echo '<tr><td>No Record Found</td></tr>';
                  }
                  ?>
               </tbody>
          </table>
        </div>
      </div>
    </div>
</div>
</div>