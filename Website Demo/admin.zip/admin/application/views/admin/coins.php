<div id="purchase" class="">
  <div class="succees-mess text-center timmer">
  <h3 class="bonus-h-custom">Change Coin Value </h3>
  </div>
</div>

<?php 
  if(isset($_SESSION['error']))
  {
?>
<!-- error -->
<div class="alert alert-danger fade in alert-dismissable">
<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
<?= $_SESSION['error'] ?>
</div>
<!-- /error -->
<?php
  }
  if(isset($_SESSION['success']))
  {
?>
<!-- success -->
<div class="alert alert-success fade in alert-dismissable">
<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
<?= $_SESSION['success'] ?>
</div>
<!-- /success -->
<?php 
}
?>

<!--inner block start here-->
<div class="inbox-mail">
  <!-- <div class="col-md-4 compose w3layouts">
    <nav class="nav-sidebar">
      <ul class="nav tabs">
        <li class="active"><a href="#tab1" data-toggle="tab" aria-expanded="false"><i class="fa fa-inbox"></i>Basic Information  <div class="clearfix"></div></a></li>
      </ul>
    </nav>
  </div> -->
  <!-- tab content -->
  <div class="col-md-12 tab-content tab-content-in text-left w3">
    <div class="tab-pane active text-style" id="tab1">
      <div class="inbox-right">
        <div class="">
          <?php 
          $values = get_record('*','sk_coin_value',array('c_id !=' => '', ));
          ?>
          <h4 id="forms-horizontal">Change Coin Value</h4>
          <form id="personalInfoform" class="form-horizontal" name="personalInfoForm" action="<?= base_url() ?>admin/update_coin_value" method="post" />
            <div class="form-group">
              <div class="col-sm-12">
                <label for="mobile"> BTC Price</label>
                <input class="form-control" value="<?= $values->c_btc_value ?>"  name="btc" type="text" placeholder="BTC Price">
              </div>
            </div>
           
            <div class="form-group">
              <div class="col-sm-12">
                <label for="fullname"> ETH Price </label>
                <input type="text" name="eth" class="form-control" value="<?= $values->c_eth_value ?>"  placeholder="ETH Price">
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-12">
                <button type="submit" class="btn-primary btn">Update Value</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div class="clearfix"> </div>

<div id="purchase" class="">
  <div class="succees-mess text-center timmer">
  <h3 class="bonus-h-custom">SNK Stock </h3>
  </div>
</div>
  <!-- SNK Coins -->
   <div class="col-md-12 tab-content tab-content-in text-left w3">
    <div class="tab-pane active text-style" id="tab1">
      <div class="inbox-right">
        <div class="">
          <?php 
          $values = get_record('*','sk_coin_value',array('c_id !=' => '', ));
          ?>
          <h4 id="forms-horizontal">SNK Coin Stock</h4>
          <form id="personalInfoform" class="form-horizontal" name="personalInfoForm" action="<?= base_url() ?>admin/update_snk" method="post" />
            <div class="form-group">
              <div class="col-sm-12">
                <label for="mobile"> SNK Coin</label>
                <input class="form-control" value="<?= $values->snk_coins ?>"  name="snk-coin" type="text" placeholder="SNK Coin Stock">
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-12">
                <button type="submit" class="btn-primary btn">Update Value</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div class="clearfix"> </div>
</div>
<!--inner block end here-->
          <div class="copyrights">
            <p><b><a href="#" >Snakeeater </a>©Copyright 2017 / All Rights Reserved</b></p>
          </div>
          <!--COPY rights end here-->
        </div>
      </div>
      <!--//content-inner-->