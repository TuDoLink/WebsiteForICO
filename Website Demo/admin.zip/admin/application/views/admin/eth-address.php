<div id="purchase" class="">
  <div class="succees-mess text-center timmer">
  <h3 class="bonus-h-custom">Change ETH Address </h3>
  </div>
</div>

<?php 
  if(isset($_SESSION['error']))
  {
?>
<!-- error -->
<div class="alert alert-danger fade in alert-dismissable">
<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
<?= $_SESSION['error'] ?>
</div>
<!-- /error -->
<?php
  }
  if(isset($_SESSION['success']))
  {
?>
<!-- success -->
<div class="alert alert-success fade in alert-dismissable">
<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
<?= $_SESSION['success'] ?>
</div>
<!-- /success -->
<?php 
}
?>

<!--inner block start here-->
<div class="inbox-mail">
  <!-- tab content -->
  <div class="col-md-12 tab-content tab-content-in text-left w3">
    <div class="tab-pane active text-style" id="tab1">
      <div class="inbox-right">
        <div class="">
          <?php 
          $values = get_record('dtl_eth_address','sk_admin_detail',array('dtl_id !=' => '', ));
          ?>
          <h4 id="forms-horizontal">Change ETH Address</h4>
          <form id="personalInfoform" class="form-horizontal" name="personalInfoForm" action="<?= base_url() ?>admin/update_ethcoin" method="post" />
            <div class="form-group">
              <div class="col-sm-12">
                <label for="mobile"> ETH Address </label>
                <input class="form-control" value="<?= $values->dtl_eth_address ?>"  name="eth-address" type="text" placeholder="Enter Valid ETH Address">
              </div>
            </div>
            
            <div class="form-group">
              <div class="col-sm-12">
                <button type="submit" class="btn-primary btn">Update</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div class="clearfix"> </div>
</div>
<!--inner block end here-->
          <div class="copyrights">
            <p><b><a href="#" >Snakeeater </a>©Copyright 2017 / All Rights Reserved</b></p>
          </div>
          <!--COPY rights end here-->
        </div>
      </div>
      <!--//content-inner-->