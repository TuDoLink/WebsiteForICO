<div id="purchase" class="">
  <div class="succees-mess text-center timmer">
  <h3 class="bonus-h-custom"> User Accounts </h3>
  </div>
</div>

<?php 
if(isset($_SESSION['error']))
{
?>
<!-- error -->
<div class="alert alert-danger fade in alert-dismissable">
<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
<?= $_SESSION['error'] ?>
</div>
<!-- /error -->
<?php
}
if(isset($_SESSION['success']))
{
?>
<!-- success -->
<div class="alert alert-success fade in alert-dismissable">
<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
<?= $_SESSION['success'] ?>
</div>
<!-- /success -->
<?php 
}
?>
<!--inner block start here-->
<div class="card">
  <div class="card-body">
    <div class="row">
      <div class="col-md-12">
        <div class="table-responsive">
          <table id="" class="display" width="100%" cellspacing="0">
              <thead>
                  <tr>
                    <th>User ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Join Date</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
              </thead>
               <tbody>
                <?php
                $users = get_record('*','sk_user',array('u_id != ' => NULL));
                if(count($users) == 1 && $users != false)
                {
                ?>
                 <tr>
                    <td><?= 1 ?></td>
                    <td><?= $users->u_name ?></td>
                    <td><?= $users->u_email ?></td>
                    <td><?= date('d-m-Y',strtotime($users->u_joining_date)) ?></td>
                    <td>
                      <?php 
                        if($users->u_status == 1)
                          $status = '<span class="label label-success">Active</span>';
                        elseif($users->u_status == 2)
                          $status = '<span class="label label-warning">Blocked</span>';
                        else
                          $status = '<span class="label label-danger">Inactive</span>';

                        echo $status;
                      ?>
                    </td>
                    <td>                       

                          <a title="Edit" class="btn btn-xs btn-primary btn-primaryc" href="<?= base_url()?>admin/edit_user/<?= $users->u_id ?>"><span class="fa fa-edit">Edit</span></a> &nbsp;
                      </td>
                  </tr>
              <?php
                }
                elseif(count($users) < 1 || $users == false)
                {
                  echo '<tr><td>No Record</td></tr>';
                }
                else
                {
                $counter = 1;
                foreach ($users as $user) {
                ?>
                 <tr>
                    <td><?= $counter ?></td>
                    <td><?= $user->u_name ?></td>
                    <td><?= $user->u_email ?></td>
                    <td><?= date('d-m-Y',strtotime($user->u_joining_date)) ?></td>
                    <td>
                      <?php 
                       if($user->u_status == 1)
                          $status = '<span class="label label-success">Active</span>';
                        elseif($user->u_status == 2)
                          $status = '<span class="label label-warning">Blocked</span>';
                        else
                          $status = '<span class="label label-danger">Inactive</span>';

                        echo $status;
                      ?>
                    </td>
                    <td>                       

                          <a title="Edit" class="btn btn-xs btn-primary btn-primaryc" href="<?= base_url()?>admin/edit_user/<?= $user->u_id ?>"><span class="fa fa-edit">Edit</span></a> &nbsp;
                      </td>
                  </tr>
                  <?php 
                  $counter++;
                    }
                  }//else
                  ?>
               </tbody>
          </table>
        </div>
      </div>
    </div>
</div>
</div>