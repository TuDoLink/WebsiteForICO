
<div id="purchase" class="">
  <div class="succees-mess text-center timmer">
  <h3 class="bonus-h-custom">Support Tickets </h3>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <div class="row">
      <div class="col-md-12">
        <div class="table-responsive">
          <table id="" class="display" width="100%" cellspacing="0">
              <thead>
                  <tr>
                    <th>Sr.</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Subject</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
              </thead>
               <tbody>
                <?php 
                $count = 1;
                  foreach ($support as $value) {
                ?>
                 <tr>
                    <td><?= $count; ?></td>
                    <td><?= $value['u_name'] ?></td>
                    <td><?= $value['u_email'] ?></td>
                    <td><?= $value['sp_subject'] ?></td>
                    <td>
                    <?php 
                      if($value['sp_status'])
                      echo '<span class="label label-success">Replied</span>';
                      else
                      echo '<span class="label label-danger">Pending</span>';
                    ?>                   

                    </td>
                    <td>    
                        <a title="" class="btn btn-xs btn-primary btn-primaryc" href="reply/<?= $value['sp_id'] ?>"><span class="fa fa-reply">Reply</span></a>
                      </td>
                  </tr>
                <?php 
                  $count++;
                  }
                ?>
               </tbody>
          </table>
        </div>
      </div>
    </div>
</div>
</div>