<!--inner block start here-->
<div class="inbox-mail">

  <!-- tab content -->
  <div class="col-md-12 tab-content tab-content-in text-left w3">
    <div class="tab-pane active text-style" id="tab1">
      <div class="inbox-right">
        <div class="">
          <h4 id="forms-horizontal">Basic Information</h4>
           
          <form id="personalInfoform" class="form-horizontal" name="personalInfoForm" action="<?= base_url() ?>admin/update_user/<?= $user->u_id ?>" method="post" />
            <div class="form-group">
              <div class="col-sm-12">
                <label for="referral"> Sopnsor </label>
                <input class="form-control" id="referral" readonly="readonly" value="<?= $user->u_sponsor ?>"  >
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-12">
                <label for="email"> Email </label>
                <input class="form-control" id="email" readonly="readonly" type="email" value="<?= $user->u_email ?>"  >
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-12">
                <label for="fullname"> Full Name </label>
                <input class="form-control" type="text" value="<?= $user->u_name ?>" id="fullname" name="fullname" >
              </div>
            </div>
            
            <div class="form-group">
              <div class="col-sm-12">
              <label for="birthday">Birthday</label>
                  <input class="form-control" name="dob" type="text" id="datePicker4" value="<?= $user->u_dob ?>" data-date-format="yyyy-mm-dd">
              <p class="note"> Data format yyyy - mm - dd </p>
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-12">
                <label for="mobile"> Mobile No.</label>
                <input class="form-control" value="<?= $user->u_contact ?>" id="mobile" name="mobile" type="text" >
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-12">
                <label for="gender"> Gender </label>
                <?php 
                $options = array('1' => 'Male','2' => 'Female');
                  echo form_dropdown('gender',$options,$user->u_gender,'class="form-control"');
                ?>
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-12">
                <label for="country"> Country </label>
                <select class="form-control" value="" id="country" name="country" >
                   <?php 
                  $data = get_record('*','sk_country',array('country_id !=' => NULL));
                  foreach ($data as $option) {
                  if($option->country_id == $user->u_country)
                  echo "<option value=".$option->country_id." selected>".$option->country_name."</option>";
                  else
                  echo "<option value=".$option->country_id.">".$option->country_name."</option>";
                  }
                ?>
                </select>
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-12">
                <label for="status">Status</label>
                <?php 
                $options = array('1' => 'Active','2' => 'Block');
                  echo form_dropdown('status',$options,$user->u_status,'class="form-control"');
                ?>
              </div>
            </div>
            <div class="clearfix"> </div><div class="clearfix"> </div>
            <h4 id="forms-horizontal">User Balance</h4>
            <div class="form-group">
              <div class="col-sm-12">
                <label for="fullname"> Total Balance (SNK Coins)</label>
                <input class="form-control" type="text" value="<?= $user->usc_coin ?>" name="ubalance">
              </div>
            </div>
            <h4 id="forms-horizontal">Update Password</h4>
            <div class="form-group">
              <div class="col-sm-12">
              <label for="fullname"> New Password </label>
                <input type="Password" class="form-control" id="newPassword" name="newPassword" placeholder="New Password (Leave blank if not updating)">
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-12">
                <label for="fullname"> Confirm Password </label>
                <input type="Password" class="form-control" id="confirmPassword" name="confirmPassword" placeholder="Confirm New Password (Leave blank if not updating)">
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-12">
                <button class="btn-primary btn">Update Profile</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div class="clearfix"> </div>
</div>
<!--inner block end here-->

          <div class="copyrights">
            <p><b><a href="#" >Snakeeater </a> © Copyright <?= date('Y') ?> / All Rights Reserved</b></p>
          </div>
          <!--COPY rights end here-->
        </div>
      </div>
      <!--//content-inner-->