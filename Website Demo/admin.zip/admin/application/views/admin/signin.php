<section class="login_section login_section-cb">
      <center>
            </center>
      <div class="form signupform">
        <div class="text-left">
          <a style="color:gray" ><i class="fa fa-home fa-3x" aria-hidden="true"></i></a>
        </div>
        <ul class="tab-group tab_login">
          <li class="tab active" style=" width:100%"><a href="#login">Login as Admin</a></li>
        </ul>
        <div class="tab-content">
          <?php 
            if(isset($_SESSION['error']))
            {
          ?>
          <!-- error -->
          <div class="alert alert-danger fade in alert-dismissable">
          <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
          <?= $_SESSION['error'] ?>
          </div>
          <!-- /error -->
          <?php
            }
            if(isset($_SESSION['success']))
            {
          ?>
          <!-- success -->
          <div class="alert alert-success fade in alert-dismissable">
          <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
          <?= $_SESSION['success'] ?>
          </div>
          <!-- /success -->
          <?php 
          }
          ?>
          <div id="login" class="sinh_up" style="display: block;">
            <form id="loginFrm" name="login" method="post" action="<?= base_url() ?>home/check_user">
              <div class="top-row">
                <div class="field-wrap">
                  <input type="text" required autocomplete="off" id="username" name="useremail" placeholder="User Name" />
                  <span id="errorUsername" style="font-size:11px; color:#B94A48; text-align:center;"></span>
                </div>
                <div class="field-wrap">
                  <input type="password" id="password" name="password" required autocomplete="off" placeholder="Password * ">
                  <span id="errorPassword" style="font-size:11px; color:#B94A48; text-align:center;"></span>
                </div>
                <div class="field-wrap">
                  <img id="captcha" src="<?php echo base_url(); ?>assets/securimage/securimage_show.png" alt="CAPTCHA Image" /> <br>
                  <a href="#" id="captchaRefresh" onclick="document.getElementById('captcha').src = 'securimage/securimage_showd41d.png?' + Math.random(); return false">
                  <img src='<?= base_url() ?>assets/images/refresh.png' width='15px' alt="Refresh" /> <font color="#03768d"> Refresh </font>  </a>
                  <input type="text" name="captcha_code" id="captcha_code" size="10" maxlength="4" required autocomplete="off" placeholder="CAPTCHA * " />
                  <span id="errorCaptcha" style="font-size:11px; color:#B94A48; text-align:center;"></span>
                </div>
                <div id="add_err"></div>
              </div>
              <p class="forgot"><a href="<?php echo base_url(); ?>home/forgetpassword"><font color="#000066">Forgot Password?</font></a></p>
              <button class="button button-block get_star" type="submit" id="btnLogin"/> Log In </button>
            </form>
          </div>
          </div><!-- tab-content -->
          </div> <!-- /form -->
        </div>
      </section>


