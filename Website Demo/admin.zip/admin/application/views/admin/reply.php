<div id="purchase" class="">
  <div class="succees-mess text-center timmer">
  <h3 class="bonus-h-custom">  Contact US </h3>
  </div>
</div>


<!--inner block start here-->
<div class="inbox-mail">
  <!-- tab content -->
  <div class="col-md-12 tab-content tab-content-in text-left w3">
    <div class="tab-pane active text-style" id="tab1">
      <div class="inbox-right">
        <div class="">
         
          <h5> Question? We are here for you! </h5>
          <form  class="form-horizontal"  action="<?= base_url() ?>admin/replyback/<?= $support[0]['sp_id']?>" method="post" />
            <div class="form-group">
              <div class="col-sm-12">
                <label for="mobile"> Subject</label>
                <p><?= $support[0]['sp_subject'] ?></p>
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-12">
                <label for="mobile"> User Message</label>
                <p><?= $support[0]['sp_message'] ?></p>
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-12">
                <label for="fullname"> Reply </label>
                <input type="hidden" name="reciever" value="<?= $support[0]['sp_sender'] ?>">
                <textarea class="form-control" name="message" id="message" cols="50" rows="5"></textarea>
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-12 ">
                <button class="btn-primary btn">Send </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div class="clearfix"> </div>
</div>

<!--inner block end here-->       
            
<div class="copyrights">
  <p><b><a href="#" >Snakeeater </a> © Copyright <?= date('Y') ?> / All Rights Reserved</b></p>
</div>
<!--COPY rights end here-->
</div>
</div>
<!--//content-inner-->