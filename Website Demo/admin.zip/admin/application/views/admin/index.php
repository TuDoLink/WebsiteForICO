<div class="w3-agileits-pane">
  <div class="col-md-12 wthree-pan">
    <div class="panel panel-default">
      
      <div class="panel-heading"> <i class="fa fa-bell fa-fw"></i> ICO Status </div>
      <!-- /.panel-heading -->
      <?php
      $values = get_record('*','sk_coin_value',array('c_id !=' => '', ));
      $users = get_record('count(*) as count','sk_user',array('u_status' => '1', ));
      $btc = get_record('sum(ph_other_coin) as btc','sk_purchasing_history',array('ph_pm' => '2'));
      ?>
      <div class="panel-body">
        <div class="list-group">
          <div class="col-md-4">
            <a class="list-group-item"> <i class="fa fa fa-table"></i> Total members <span class="pull-right text-muted small"><em><?= number_format($users->count) ?></em> </span> </a>
          </div>  
          <div class="col-md-4">
            <a class="list-group-item"> <i class="fa fa fa-table"></i> Total Deposit <span class="pull-right text-muted small"><em><?php if($btc->btc > 0) echo $btc->btc; else echo '0'; ?> BTC</em> </span> </a>
          </div>
          <div class="col-md-4">
            <a class="list-group-item"> <i class="fa fa fa-table"></i> Remaining ICO Tokens <span class="pull-right text-muted small"><em><?= number_format($values->snk_coins) ?></em> </span> </a>
          </div>
        </div>
        <!-- /.list-group -->
      </div>
      <!-- /.panel-body -->
    </div>
  </div>
  <div class="clearfix"></div>
</div>
<div id="purchase" class="">
  <div class="succees-mess text-center timmer">
  <h3 class="bonus-h-custom">Recent User Accounts </h3>
  </div>
</div>
<!--inner block start here-->
<div class="card">
  <div class="card-body">
    <div class="row">
      <div class="col-md-12">
        <div class="table-responsive">
          <table id="" class="display" width="100%" cellspacing="0">
              <thead>
                  <tr>
                    <th>Sr.</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Join Date</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
              </thead>
               <tbody>
                <?php
                $users = get_record('sk_user.*','sk_user',array('u_id != ' => NULL),'10','u_id','desc');
                if(count($users) == 1 && $users != false)
                {
                ?>
                 <tr>
                    <td><?= 1 ?></td>
                    <td><?= $users->u_name ?></td>
                    <td><?= $users->u_email ?></td>
                    <td><?= date('d-m-Y',strtotime($users->u_joining_date)) ?></td>
                    <td>
                      <?php 
                        if($users->u_status == 1)
                          $status = '<span class="label label-success">Active</span>';
                        elseif($users->u_status == 2)
                          $status = '<span class="label label-warning">Blocked</span>';
                        else
                          $status = '<span class="label label-danger">Inactive</span>';

                        echo $status;
                      ?>
                    </td>
                    <td>                       

                          <a title="Edit" class="btn btn-xs btn-primary btn-primaryc" href="<?= base_url()?>admin/edit_user/<?= $users->u_id ?>"><span class="fa fa-edit">Edit</span></a> &nbsp;
                      </td>
                  </tr>
              <?php
                }
                elseif(count($users) < 1 ||  $users == false)
                {
                  echo '<tr><td>No Record</td></tr>';
                }
                else
                {
                $counter = 1;
                foreach ($users as $user) {
                ?>
                 <tr>
                    <td><?= $counter ?></td>
                    <td><?= $user->u_name ?></td>
                    <td><?= $user->u_email ?></td>
                    <td><?= date('d-m-Y',strtotime($user->u_joining_date)) ?></td>
                    <td>
                      <?php 
                       if($user->u_status == 1)
                          $status = '<span class="label label-success">Active</span>';
                        elseif($user->u_status == 2)
                          $status = '<span class="label label-warning">Blocked</span>';
                        else
                          $status = '<span class="label label-danger">Inactive</span>';

                        echo $status;
                      ?>
                    </td>
                    <td>                       

                          <a title="Edit" class="btn btn-xs btn-primary btn-primaryc" href="<?= base_url()?>admin/edit_user/<?= $user->u_id ?>"><span class="fa fa-edit">Edit</span></a> &nbsp;
                      </td>
                  </tr>
                  <?php 
                  $counter++;
                    }
                  }//else
                  ?>
               </tbody>
          </table>
        </div>
      </div>
    </div>
</div>
</div>

<div id="purchase" class="">
  <div class="succees-mess text-center timmer">
  <h3 class="bonus-h-custom">Recent Support Tickets </h3>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <div class="row">
      <div class="col-md-12">
        <div class="table-responsive">
          <table id="" class="display" width="100%" cellspacing="0">
              <thead>
                  <tr>
                    <th>Sr.</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Subject</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
              </thead>
               <tbody>
                <?php 
                $count = 1;
                  foreach ($support as $value) {
                    if($count < 11){
                ?>
                 <tr>
                    <td><?= $count; ?></td>
                    <td><?= $value['u_name'] ?></td>
                    <td><?= $value['u_email'] ?></td>
                    <td><?= $value['sp_subject'] ?></td>
                    <td>
                    <?php 
                      if($value['sp_status'])
                      echo '<span class="label label-success">Replied</span>';
                      else
                      echo '<span class="label label-danger">Pending</span>';
                    ?>                   

                    </td>
                    <td>    
                        <a title="" class="btn btn-xs btn-primary btn-primaryc" href="<?=base_url()?>admin/reply/<?= $value['sp_id'] ?>"><span class="fa fa-reply">Reply</span></a>
                      </td>
                  </tr>
                <?php 
                  $count++;
                }
                  }
                ?>
               </tbody>
          </table>
        </div>
      </div>
    </div>
</div>
</div>

<!--inner block end here-->       

<div class="copyrights">
  <p><b><a href="#" >Snakeeater </a> © Copyright <?= date('Y') ?> / All Rights Reserved</b></p>
</div>
<!--COPY rights end here-->
</div>
</div>
<!--//content-inner-->