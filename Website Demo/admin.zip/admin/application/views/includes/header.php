<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>SnakeEater</title>
        <!-- Chrome, Firefox OS and Opera -->
<meta name="theme-color" content="#000066">
<!-- Windows Phone -->
<meta name="msapplication-navbutton-color" content="#000066">
<!-- iOS Safari -->
<meta name="apple-mobile-web-app-status-bar-style" content="#000066">
        <meta name="description" content="Snakeeater Blockchain Technologies limited makes Crypto currency easier to purchase and transfer. SNK has developed cutting edge technology blockchain. The Company has built-in house capability and expertise to understand the full potential of this revolutionary technology. Team SNK is in the trade of technology, blockchain, Bigdata & firmware for more than a decade with numerous recognitions accredited.">
        <meta name="keywords" content=" best cryptocurrency to invest, best">
        <link rel="shortcut icon" type="image/png" href="<?php echo base_url(); ?>assets/favicon.png"/>
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/foundation.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/fontello.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
        <link rel="stylesheet" media="screen" href="<?php echo base_url(); ?>assets/css/custom.css">
        <link rel="stylesheet" media="screen" href="<?php echo base_url(); ?>assets/css1/style-new.css">
        <link rel="stylesheet" media="screen" href="<?php echo base_url(); ?>assets/css1/style.css">
        

        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css1/slider.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css1/custom-new.css">
        <!-- bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <!-- /bootstrap -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css1/slider.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css1/custom-new.css">
        <script src="http://use.fontawesome.com/b7d2788846.js"></script>
        <script src='http://www.google.com/recaptcha/api.js'></script>
</head>
<body>
        <div class="">
                <div id="av-top-bar" class="topo-b-c">
                    <div class="row">
                        <a href="#" class="av-mobile-toggle"><i class="fa fa-bars" aria-hidden="true"></i></a>
                        <div class="column large-4 logo_main">
                            <a href="<?php echo base_url(); ?>">
                            <figure><img src="<?php echo base_url(); ?>assets/images/logo.png" alt="logo"></figure>
                            </a>
                        </div>
                        <div class="column large-8">
                            <nav class="av-main-nav">
                                <ul>
                                    <li ><a href="<?php echo base_url(); ?>">Home</a></li>
                                    <li data-scroll-nav="0"><a>about us</a></li>
                                    <li><a href="<?php echo base_url(); ?>home/faq">F.A.Q</a></li>
                                    <li ><a href="<?php echo base_url(); ?>home/terms">Terms</a></li>
                                    <li><a href="<?php echo base_url(); ?>assets/whitepaper/Welcome to SNAKE EATER COIN white paper AND ROAD MAP.pdf" target="_blank"> White Paper</a></li>
                                    <li><a href="<?php echo base_url(); ?>home/privacy">Privacy</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
        </div>