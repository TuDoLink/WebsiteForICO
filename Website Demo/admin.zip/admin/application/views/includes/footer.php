<!-- <section id="social-links" class="av-contact-section av-contact-custom">
    <div class="row">
        <div class="column large-12">
            <div class="av-social">
                <div class="container">
                        <ul>
                        
                          <li class="scrollimation fade-up d2" data-sr="enter bottom please, move 100px,over 0.9s">
                            
                            <a href="https://www.facebook.com" target="_blank" class="icon"><h2 class="icon-h-cf">f</h2></a>
                            <h4 class="social-links-c">Connect on Facebook</h4>
                          </li>
                          <li class="scrollimation fade-up d2 fade-up-c" data-sr="wait 0.2s, enter bottom please, move 100px,over 0.9s">
                            
                            <a href="https://www.twitter.com" target="_blank" class="icon"><h2 class="icon-h-ct">t</h2></a>
                            <h4 class="social-links-c">Connect on Twitter</h4>
                          </li>
                          <li class="scrollimation fade-up d2 fade-up-c" data-sr="wait 0.4s, enter bottom please, move 100px,over 0.9s">
                            
                            <a href="https://www.twitter.com" target="_blank" class="icon"><h2 class="icon-h-cy">y</h2></a>
                            <h4 class="social-links-c">Connect on Youtube</h4>
                          </li>
                        </ul>
                          
                      </div>
                
            </div>
        </div>
    </div>
</section>


<div class="av-copyright-section bg-dark" data-scroll-index="5">
    <div class="row">
        <div class="column large-6">
            <p class="center-c-text">

<a href="#" >Snakeeater </a>©Copyright 2017 / All Rights Reserved</p>
        </div>
        <div class="column large-2 text-center">
            
        </div>
        <div class="column large-4 text-center">
           <!--  <ul class="footer_menu pull-right ">
                <li><button class="sub-btn"  id="Subscribe" type="submit">Subscribe</button> </li>
               
            </ul> -->
            <!-- <ul class="footer_menu">
                <li> <a href="<?php echo base_url(); ?>assets/guide/Privacy_Policy.pdf" target="_blank">Privacy Policy</a> | </li>
                <li>  <a href="<?php echo base_url(); ?>assets/guide/Terms_of_Use.pdf" target="_blank">Terms of Use </a></li>
            </ul>
        </div>
    </div>
</div> -->
<!-- Subscribe pop  -->
<!-- <div class="popupbg"></div>
<div class="popupindex">
    <figure class="text-center"><img width="50%" src="images/etherecash.png" alt="logo"><p>Subscribe For Latest Update</p></figure>
    <a href="javascript:voide(0);"><div id="cross" class="cross"><img src="<?php echo base_url(); ?>assets/images/default_button-cross.png"></div>></a>
    <section class="av-services-section  av-contact-section"  data-equalizer data-scroll-index="2">
        <div class="column large-12 ">
            <div class="row">
                <div class="form-contact">
                    <form action="https://www.etherecash.io/subscribe.php" method="post">
                        <div class="column large-6">
                            <input class="av-input"  id="Email" placeholder="Email" name="email" type="email" type="email" required />
                        </div>
                        <div class="column  large-6  btn-content">
                            <p>
                                <button class="av-submit" type="submit">Subscribe  </button>
                            </p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
</div> -->

<!-- / Subscribe pop  -->
<!-- <script src="<?php echo base_url(); ?>assets/js1/particles.js"></script>
<script src="<?php echo base_url(); ?>assets/js1/app.js"></script> -->
<!-- stats.js -->
<!-- <script src="<?php echo base_url(); ?>assets/js1/jquery-2.2.4.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js1/jquery.themepunch.revolution.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js1/jquery.themepunch.revolution2.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js1/slideanims.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js1/layeranimation.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js1/navigation.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js1/main.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/foundation.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/foundation.equalizer.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/scrollIt.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/waypoints.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/countUp.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/scrollReveal.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
 <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.chocolate.js"></script>
 <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/three.min.js"></script>
<script src="https://use.fontawesome.com/850ee8b9ad.js"></script>
</body>

</html>  -->



<section id="social-links" class="av-contact-section av-contact-custom">
    <div class="row">
        <div class="column large-12">
            <div class="av-social">
                <div class="container">
                        <ul>
                        
                          <li class="scrollimation fade-up d2" data-sr="enter bottom please, move 100px,over 0.9s">
                            
                            <a href="https://www.facebook.com" target="_blank" class="icon"><h2 class="icon-h-cf">f</h2></a>
                            <h4 class="social-links-c">Connect on Facebook</h4>
                          </li>
                          <li class="scrollimation fade-up d2 fade-up-c" data-sr="wait 0.2s, enter bottom please, move 100px,over 0.9s">
                            
                            <a href="https://www.twitter.com" target="_blank" class="icon"><h2 class="icon-h-ct">t</h2></a>
                            <h4 class="social-links-c">Connect on Twitter</h4>
                          </li>
                          <li class="scrollimation fade-up d2 fade-up-c" data-sr="wait 0.4s, enter bottom please, move 100px,over 0.9s">
                            
                            <a href="https://www.twitter.com" target="_blank" class="icon"><h2 class="icon-h-cy">y</h2></a>
                            <h4 class="social-links-c">Connect on Youtube</h4>
                          </li>
                        </ul>
                          
                      </div>
                
            </div>
        </div>
    </div>
</section>


<div class="av-copyright-section bg-dark" data-scroll-index="5">
    <div class="row">
        <div class="column large-6">
            <p class="center-c-text">

<a href="#" >Snakeeater </a>©Copyright 2017 / All Rights Reserved</p>
        </div>
        <div class="column large-2 text-center">
            
        </div>
        <div class="column large-4 text-center">
           <!--  <ul class="footer_menu pull-right ">
                <li><button class="sub-btn"  id="Subscribe" type="submit">Subscribe</button> </li>
               
            </ul> -->
            <ul class="footer_menu">
                <li> <a href="<?php echo base_url(); ?>assets/guide/Privacy_Policy.pdf" target="_blank">Privacy Policy</a> | </li>
                <li>  <a href="<?php echo base_url(); ?>assets/guide/Terms_of_Use.pdf" target="_blank">Terms of Use </a></li>
            </ul>
        </div>
    </div>
</div>
<!-- Subscribe pop  -->
<div class="popupbg"></div>
<div class="popupindex">
    <figure class="text-center"><img width="50%" src="images/etherecash.png" alt="logo"><p>Subscribe For Latest Update</p></figure>
    <a href="javascript:voide(0);"><div id="cross" class="cross"><img src="<?php echo base_url(); ?>assets/images/default_button-cross.png"></div>></a>
    <section class="av-services-section  av-contact-section"  data-equalizer data-scroll-index="2">
        <div class="column large-12 ">
            <div class="row">
                <div class="form-contact">
                    <form action="https://www.etherecash.io/subscribe.php" method="post">
                        <div class="column large-6">
                            <input class="av-input"  id="Email" placeholder="Email" name="email" type="email" type="email" required />
                        </div>
                        <div class="column  large-6  btn-content">
                            <p>
                                <button class="av-submit" type="submit">Subscribe  </button>
                            </p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- / Subscribe pop  -->
<script src="<?php echo base_url(); ?>assets/js1/particles.js"></script>
<script src="<?php echo base_url(); ?>assets/js1/app.js"></script>
<!-- stats.js -->
<script src="<?php echo base_url(); ?>assets/js1/jquery-2.2.4.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js1/jquery.themepunch.revolution.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js1/jquery.themepunch.revolution2.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js1/slideanims.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js1/layeranimation.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js1/navigation.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js1/main.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/foundation.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/foundation.equalizer.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/scrollIt.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/waypoints.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/countUp.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/scrollReveal.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
 <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.chocolate.js"></script>
 <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/three.min.js"></script>
<script src="https://use.fontawesome.com/850ee8b9ad.js"></script>

<script>
      $('.form').find('input, textarea').on('keyup blur focus', function (e) {
      var $this = $(this),
      label = $this.prev('label');
      if (e.type === 'keyup') {
      if ($this.val() === '') {
      label.removeClass('active highlight');
      } else {
      label.addClass('active highlight');
      }
      } else if (e.type === 'blur') {
      if( $this.val() === '' ) {
      label.removeClass('active highlight');
      } else {
      label.removeClass('highlight');
      }
      } else if (e.type === 'focus') {
      if( $this.val() === '' ) {
      label.removeClass('highlight');
      }
      else if( $this.val() !== '' ) {
      label.addClass('highlight');
      }
      }
      });
      $('.tab a').on('click', function (e) {
      e.preventDefault();
      $(this).parent().addClass('active');
      $(this).parent().siblings().removeClass('active');
      target = $(this).attr('href');
      $('.tab-content > div').not(target).hide();
      $(target).fadeIn(600);
      });
      var password = document.getElementById("reg_password")
      , confirm_password = document.getElementById("confirm_password");
      function validatePassword(){
      if(password.value != confirm_password.value) {
      confirm_password.setCustomValidity("Password does not match!");
      } else {
      confirm_password.setCustomValidity('');
      }
      }
      password.onchange = validatePassword;
      confirm_password.onkeyup = validatePassword;
      var reg_username = document.getElementById("reg_username")
      , reg_username_repeat = document.getElementById("reg_username_repeat");
      function validateRegUsername(){
      if(reg_username.value.toLowerCase() != reg_username_repeat.value.toLowerCase()) {
      reg_username_repeat.setCustomValidity("Email does not match!");
      } else {
      reg_username_repeat.setCustomValidity('');
      }
      }
      reg_username.onchange = validateRegUsername;
      reg_username_repeat.onkeyup = validateRegUsername;
      var reg_captcha = document.getElementById("reg_username");
      function updRegCaptcha(){
      document.getElementById('reg_captcha').src = 'securimage/securimage_showd41d.png?' + Math.random();
      }
      reg_username.onchange = updRegCaptcha;
      </script>

      
  </body>

</html>