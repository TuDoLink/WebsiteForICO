<div class="left-content">
  <div class="mother-grid-inner">
    <!--header start here-->
    <?php 
    $values = get_record('*','sk_coin_value',array('c_id !=' => '', ));
    $users = get_record('count(*) as count','sk_user',array('u_status' => '1', ));
    ?>
    <div class="header-main">
      <div class="row">
        <div class="col-md-4">
          <div class="logo-w3-agile">
            <div class=" list-group-alternate">
              <a href="<?= base_url() ?>admin/coins" class="list-group-item"><span class="badge badge-danger"> <?= $values->c_btc_value ?> </span> <i class="ti ti-email"></i> <b>BTC Price</b> </a>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="logo-w3-agile">
            <div class=" list-group-alternate">
              <a href="<?= base_url() ?>admin/coins" class="list-group-item"><span class="badge badge-danger"><?= $values->c_eth_value ?></span> <i class="ti ti-email"></i> <b>ETH Price</b> </a>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="logo-w3-agile">
            <div class=" list-group-alternate">
            <a href="<?= base_url() ?>admin/coins" class="list-group-item"><span class="badge badge-danger"><?= number_format($users->count) ?></span> <i class="ti ti-email"></i>  <b>ICO Participants</b>  </a>
            </div>
          </div>
          <div class="clearfix"> </div>
        </div>
      </div>
    </div>
    <!--heder end here--> 