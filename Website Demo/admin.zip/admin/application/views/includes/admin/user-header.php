<!DOCTYPE HTML>
<html>
<head>
<title>Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="theme-color" content="#000066">
<!-- Windows Phone -->
<meta name="msapplication-navbutton-color" content="#000066">
<!-- iOS Safari -->
<meta name="apple-mobile-web-app-status-bar-style" content="#000066">
    <!-- Bootstrap Core CSS -->
<link href="<?= base_url() ?>assets/snk/css/table-style.css" rel='stylesheet' type='text/css' />
<link href="<?= base_url() ?>assets/snk/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="<?= base_url() ?>assets/snk/css/style.css" rel='stylesheet' type='text/css' />
<link href="<?= base_url() ?>assets/snk/css/custom.css" rel='stylesheet' type='text/css' />

<link rel="stylesheet" href="<?= base_url() ?>assets/snk/css/morris.css" type="text/css"/>
   <link href="<?= base_url() ?>assets/snk/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">

<link rel="shortcut icon" type="<?= base_url() ?>assets/image/png" href="favicon.png"/>
    <!-- jQuery -->
    <script src="<?= base_url() ?>assets/snk/js/jquery-2.1.4.min.js"></script>
  </head>

  <body>
  <div id="home" class="page-container">
    <!--/sidebar-menu-->
    <div class="sidebar-menu">
      <header class="logo1">
        <a href="<?= base_url() ?>admin" class=""> <img alt="logo" src="<?= base_url() ?>assets/snk/img/logo.png"> </a>
      </header>
      <div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
        <div class="menu">
            <ul id="menu" >
              <li>
                 <a  href="<?= base_url() ?>admin">
                    <i class="fa fa-tachometer"></i> <span>Dashboard</span>
                    <div class="clearfix"></div>
                 </a>
              </li>
              <li id="menu-academico" >
                 <a href="<?= base_url() ?>admin/u_account">
                    <i class="fa  fa-user"></i><span>User Accounts</span>
                    <div class="clearfix"></div>
                 </a>
              </li>
              <li id="menu-academico" >
                 <a href="<?= base_url() ?>admin/funds">
                    <i class="fa  fa-user"></i><span>ETH Funds</span>
                    <div class="clearfix"></div>
                 </a>
              </li>
              <li id="menu-academico" >
                 <a href="<?= base_url() ?>admin/support">
                    <i class="fa fa-lg fa-fw fa-envelope-o"></i><span>Support</span>
                    <div class="clearfix"></div>
                 </a>
              </li>
              <li id="menu-academico" >
                 <a href="<?= base_url() ?>admin/coins">
                    <i class="fa fa-superpowers"></i><span>Coin Value</span>
                    <div class="clearfix"></div>
                 </a>
              </li><li id="menu-academico" >
                 <a href="<?= base_url() ?>admin/news">
                    <i class="fa fa-superpowers"></i><span>Dashboard News</span>
                    <div class="clearfix"></div>
                 </a>
              </li>
              </li><li id="menu-academico" >
                 <a href="<?= base_url() ?>admin/ethcoin_address">
                    <i class="fa fa-superpowers"></i><span>ETH Address</span>
                    <div class="clearfix"></div>
                 </a>
              </li>
              <li id="menu-academico" >
                 <a href="<?= base_url() ?>admin/logout">
                    <i class="fa fa-power-off"></i><span> Log Out </span>
                    <div class="clearfix"></div>
                 </a>
              </li>
            </ul>
        </div>      
    </div>
    <div class="clearfix"></div>
