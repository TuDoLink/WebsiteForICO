<?php
// fetch all records
function get_record($select,$table,$condition,$limit = NULL,$order_by = NULL,$order_type = NULL)
 {
 	if(!isset($select))
 	{
 		$select = '*';
 	}
  	$ci =& get_instance();
  	$ci->db->select($select);
  	$ci->db->where($condition);
  	if(isset($limit))
  	{
  		$ci->db->order_by($order_by,$order_type);
  		$ci->db->limit($limit);
  	}
	$row = $ci->db->get($table);
	if($row->num_rows() > 0)
	{
		if($row->num_rows() > 1)
		{
		return $row->result();
		}
		else
		{
			return $row->row();
		}
	}
	else
	{
		return false;
	}
 }

 function get_stat($select,$table,$condition)
 {
 	if(!isset($select))
 	{
 		$select = '*';
 	}
  	$ci =& get_instance();
  	$ci->db->select($select);
  	$ci->db->where($condition);
	return $ci->db->get($table)->row()->count;
 }

?>