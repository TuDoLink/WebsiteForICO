<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		if($this->session->userdata('s_id'))
		{
			redirect('http://beta.snakeeater.io/user/');
		}
		$this->load->model('Home_m');
	}

	public function index()
	{
		$this->load->view('includes/header');
		$this->load->view('admin/signin');
		$this->load->view('includes/footer');
	}

	function check_user()
	{
		$this->form_validation->set_rules('useremail','Email','trim|required');
		$this->form_validation->set_rules('password','Password','trim|required');
		if ($this->form_validation->run() == FALSE) {
			$error = array();
			$error = validation_errors();
			$this->session->set_flashdata('error', $error);
			redirect('/');
		} else {
			$data = array(
				'ad_username' => $this->input->post('useremail'),
				'ad_password' => $this->input->post('password'),
			);
			$result = $this->Home_m->check_user($data);
			if($result)
			{	
				redirect('admin/');
			} else {
				$this->session->set_flashdata('error', 'Invalid Details.Try again with right detail');
				redirect('home/');
			}
		}	
	}
}
