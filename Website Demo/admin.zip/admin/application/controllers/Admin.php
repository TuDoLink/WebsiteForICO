<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('s_admin'))
		{
			redirect('/');
		}
		$this->load->model('Admin_m');
		$this->load->helper('admin');
	}
	
	public function index()
	{
		$data['support'] = $this->Admin_m->dashboard_support();
		$this->load->view('includes/admin/user-header');
		$this->load->view('includes/admin/common-facts');
		$this->load->view('admin/index',$data);
	}
	public function u_account()
	{
		$this->load->view('includes/admin/user-header');
		$this->load->view('includes/admin/common-facts');
		$this->load->view('admin/users');
	}
	public function news()
	{
		$this->load->view('includes/admin/user-header');
		$this->load->view('includes/admin/common-facts');
		$this->load->view('admin/news');
	}
	public function support()
	{
		$data['support'] = $this->Admin_m->support();
		$this->load->view('includes/admin/user-header');
		$this->load->view('includes/admin/common-facts');
		$this->load->view('admin/support',$data);
	}
	public function coins()
	{
		$this->load->view('includes/admin/user-header');
		$this->load->view('includes/admin/common-facts');
		$this->load->view('admin/coins');
	}
	public function ethcoin_address()
	{
		$this->load->view('includes/admin/user-header');
		$this->load->view('includes/admin/common-facts');
		$this->load->view('admin/eth-address');
	}
	public function funds()
	{
		$data['funds'] = $this->Admin_m->funds();
		$this->load->view('includes/admin/user-header');
		$this->load->view('includes/admin/common-facts');
		$this->load->view('admin/eth-funds',$data);
	}
	function funds_approval($id)
	{
		$this->Admin_m->funds_approval($id);
		$this->session->set_flashdata('success', 'Aprroved Successfully');
		redirect('admin/funds');
	}
	function edit_user($user = NULL)
	{
		if(!isset($user))
		{
			redirect('admin/');
		}
		$data['user'] = $this->Admin_m->edit_user($user);
		$this->load->view('includes/admin/user-header');
		$this->load->view('includes/admin/common-facts');
		$this->load->view('admin/edit-user',$data);
	}
	function update_user($user = NULL)
	{
		if(!isset($user))
		{
			redirect('admin/');
		}
		$this->form_validation->set_rules('fullname','User Name','trim|required');
		$this->form_validation->set_rules('dob','Date of Birth','trim');
		$this->form_validation->set_rules('mobile','Mobile Number','trim|numeric');
		$this->form_validation->set_rules('gender','Gender','trim');
		$this->form_validation->set_rules('country','Country','trim');
		$this->form_validation->set_rules('status','Status','trim');
		$this->form_validation->set_rules('ubalance','Total balance','trim|numeric');
		$this->form_validation->set_rules('newPassword','Password','trim|min_length[6]|max_length[20]');
		if ($this->form_validation->run() == FALSE) {
			$error = array();
			$error = validation_errors();
			$this->session->set_flashdata('error', $error);
			redirect('admin/u_account');
		} else {
			if($this->input->post('newPassword') != '')
			{
				if($this->input->post('newPassword') == $this->input->post('confirmPassword'))
				{
					$data = array(
					'u_name' => $this->input->post('fullname'),
					'u_dob' => $this->input->post('dob'),
					'u_contact' => $this->input->post('mobile'),
					'u_gender' => $this->input->post('gender'),
					'u_country' => $this->input->post('country'),
					'u_status' => $this->input->post('status'),
					'u_password' => $this->input->post('newPassword')
					);
					$this->Admin_m->update_user($user,$data,$this->input->post('ubalance'));
					$this->session->set_flashdata('success', 'Updated Successfully');
					redirect('admin/u_account');
				}
				else
				{
					$this->session->set_flashdata('error', 'Password Mismatch');
					redirect('admin/u_account');
				}
			}
			else
			{
				$data = array(
					'u_name' => $this->input->post('fullname'),
					'u_dob' => $this->input->post('dob'),
					'u_contact' => $this->input->post('mobile'),
					'u_gender' => $this->input->post('gender'),
					'u_country' => $this->input->post('country'),
					'u_status' => $this->input->post('status'),
					);
					$this->Admin_m->update_user($user,$data,$this->input->post('ubalance'));
					$this->session->set_flashdata('success', 'Updated Successfully');
					redirect('admin/u_account');
			}
		}	
	}

	public function reply($id = NULL)
	{
		if(!isset($id))
		{
			redirect('admin/support');
		}
		$data['support'] = $this->Admin_m->support($id);
		$this->load->view('includes/admin/user-header');
		$this->load->view('includes/admin/common-facts');
		$this->load->view('admin/reply',$data);
	}

	public function replyback($id)
	{
		$this->form_validation->set_rules('reciever','This','trim|required|numeric');
		$this->form_validation->set_rules('message','Message','trim|required');
		if ($this->form_validation->run() == FALSE) {
			$error = array();
			$error = validation_errors();
			$this->session->set_flashdata('error', $error);
			redirect('admin/support');
		} else {
			$data = array(
				'sp_sender' => 'admin',
				'sp_reciever' => $this->input->post('reciever'),
				'sp_subject' => 'Admin response',
				'sp_message' => $this->input->post('message'),
				'sp_status' => 1,
			);
			$this->Admin_m->replyback($data,$id);
			$this->session->set_flashdata('success', 'Replied successfulplly');
			redirect('admin/support');
		}	
	}
	
	public function update_coin_value()
	{
		$this->form_validation->set_rules('btc','BTC Value','trim|required|numeric');
		$this->form_validation->set_rules('eth','Eth Value','trim|required|numeric');
		if ($this->form_validation->run() == FALSE) {
			$error = array();
			$error = validation_errors();
			$this->session->set_flashdata('error', $error);
			redirect('admin/coins');
		} else {
			$data = array(
				'c_btc_value' => $this->input->post('btc'),
				'c_eth_value' => $this->input->post('eth')
			);
			$this->Admin_m->update_coin_value($data);
			$this->session->set_flashdata('success', 'Value updated successfully');
			redirect('admin/coins');
		}	
	}

	public function update_news()
	{
		$this->form_validation->set_rules('news','News','trim|required');
		if ($this->form_validation->run() == FALSE) {
			$error = array();
			$error = validation_errors();
			$this->session->set_flashdata('error', $error);
			redirect('admin/news');
		} else {
			$data = array(
				'dn_news' => $this->input->post('news')
			);
			$this->Admin_m->update_news($data);
			$this->session->set_flashdata('success', 'News updated successfully');
			redirect('admin/news');
		}	
	}

	function update_ethcoin()
	{
		$this->form_validation->set_rules('eth-address','ETH Address','trim|required');
		if ($this->form_validation->run() == FALSE) {
			$error = array();
			$error = validation_errors();
			$this->session->set_flashdata('error', $error);
			redirect('admin/ethcoin_address');
		} else {
			$data = array(
				'dtl_eth_address' => $this->input->post('eth-address')
			);
			$this->Admin_m->update_ethcoin($data);
			$this->session->set_flashdata('success', 'ETH address updated successfully');
			redirect('admin/ethcoin_address');
		}	
	}

	function update_snk()
	{
		$this->form_validation->set_rules('snk-coin','SNK Stock','trim|required|numeric');
		if ($this->form_validation->run() == FALSE) {
			$error = array();
			$error = validation_errors();
			$this->session->set_flashdata('error', $error);
			redirect('admin/coins');
		} else {
			$data = array(
				'snk_coins' => $this->input->post('snk-coin')
			);
			$this->Admin_m->update_snk($data);
			$this->session->set_flashdata('success', 'SNK Stock Value Updated');
			redirect('admin/coins');
		}	
	}

	public function logout()
	{
		session_destroy();
		redirect('/');
	}
}//end
