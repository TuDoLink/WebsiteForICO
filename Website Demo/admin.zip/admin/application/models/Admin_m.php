<?php
class Admin_m extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function check_user($data)
	{
		$this->db->where($data);
		$result = $this->db->get('sk_user');
		if ($result->num_rows() == 1) {
			$this->db->select('*');
			$this->db->where('u_email',$data['u_email']);
			$session_data = $this->db->get('sk_user')->row();

			$this->db->select('u_id,u_status');
			$this->db->where('u_id',$session_data->u_id);
			$other_data = $this->db->get('sk_user')->row();
			//set session data
			$this->session->set_userdata(
				array(
				's_id' => $session_data->u_id,
				's_active' => $session_data->u_status,
				'loggedin' => TRUE
				)
			);
			
			return true;
		} 
		else{
			return false;
		}
	}

	function update_coin_value($data)
	{
		$this->db->where('c_id !=','');
		$this->db->update('sk_coin_value',$data);
		return true;
	}

	function update_news($data)
	{
		$this->db->where('dn_id !=','');
		$this->db->update('sk_dashboard_news',$data);
		return true;
	}

	function update_ethcoin($data)
	{
		$this->db->where('dtl_id !=','');
		$this->db->update('sk_admin_detail',$data);
		return true;
	}

	function update_snk($data)
	{
		$this->db->where('c_id !=','');
		$this->db->update('sk_coin_value',$data);
		return true;
	}

	function funds()
	{
		$this->db->select('sk_purchasing_history.*,sk_user.u_name,u_email');
		$this->db->join('sk_user','sk_user.u_id = sk_purchasing_history.ph_user_id ');
		$this->db->where('ph_pm',1);
		$this->db->where('ph_status',0);
		return $this->db->get('sk_purchasing_history')->result_array();
	}

	function funds_approval($id)
	{
		$this->db->select('sk_purchasing_history.*,sk_user.*');
		$this->db->join('sk_user','sk_user.u_id = sk_purchasing_history.ph_user_id ');
		$this->db->where('ph_id',$id);
		$rec = $this->db->get('sk_purchasing_history')->result_array();
		if($rec[0]['u_sponsor'] != NULL)
		{
			$this->db->select('u_id');
			$this->db->where('u_referral_code',$rec[0]['u_sponsor']);
			$sponsor = $this->db->get('sk_user')->row()->u_id;
			// amount commision
			$this->db->select('usc_coin');
			$this->db->where('usc_user_id',$sponsor);
			$sponsor_coin = $this->db->get('sk_user_snk_coin')->row()->usc_coin;
			// wponupdate
			$bonus = ($rec[0]['ph_snk_amount'] * 0.05) + ($sponsor_coin);
			$this->db->where('usc_user_id',$sponsor);
			$this->db->update('sk_user_snk_coin',array('usc_coin' => $bonus));
			
		}
		$this->db->select('usc_coin');
		$this->db->where('usc_user_id',$rec[0]['ph_user_id']);
		$user_coin = $this->db->get('sk_user_snk_coin')->row()->usc_coin;
		$net = ($rec[0]['ph_snk_amount']) + ($user_coin);
		$this->db->where('usc_user_id',$rec[0]['ph_user_id']);
		$this->db->update('sk_user_snk_coin',array('usc_coin' => $net));
		//apporval
		$this->db->where('ph_id',$id);
		$this->db->update('sk_purchasing_history',array('ph_status' => 1));
		return true;
	}

	function edit_user($id)
	{
		$this->db->select('sk_user_snk_coin.*,sk_user.*');
		$this->db->join('sk_user_snk_coin','sk_user_snk_coin.usc_user_id=sk_user.u_id');
		$this->db->where('u_id',$id);
		$row = $this->db->get('sk_user');
		if ($row->num_rows() > 0) {
			return $row->row();
		}
		else
		{
			return false;
		}
	}

	function update_user($id,$data,$balance)
	{
		$this->db->where('u_id',$id);
		$this->db->update('sk_user',$data);

		$this->db->where('usc_user_id',$id);
		$this->db->update('sk_user_snk_coin',array('usc_coin' => $balance));
		return true;
	}

	function support($id = NULL)
	{
		$this->db->select('sk_support.*,sk_user.u_id,u_name,u_email');
		$this->db->join('sk_user','sk_user.u_id=sk_support.sp_sender');
		$this->db->where('sp_reciever','admin');
		if(isset($id))
		{
			$this->db->where('sp_id',$id);
		}
		return $this->db->get('sk_support')->result_array();	
	}

	function dashboard_support($id = NULL)
	{
		$this->db->select('sk_support.*,sk_user.u_id,u_name,u_email');
		$this->db->join('sk_user','sk_user.u_id=sk_support.sp_sender');
		$this->db->where('sp_reciever','admin');
		$this->db->where('sp_status',0);
		$this->db->order_by('sp_id','desc');
		if(isset($id))
		{
			$this->db->where('sp_id',$id);
		}
		return $this->db->get('sk_support')->result_array();	
	}

	function replyback($data,$id)
	{
		$this->db->where('sp_id',$id);
		$this->db->update('sk_support',array('sp_status' => 1));
		$this->db->insert('sk_support',$data);
		return true;
	}

}//end