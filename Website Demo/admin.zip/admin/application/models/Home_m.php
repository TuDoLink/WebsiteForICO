<?php
class Home_m extends CI_Model
{

	function __construct()
	{
		parent::__construct();
	}

	function check_user($data)
	{
		$this->db->where($data);
		$result = $this->db->get('sk_admin');
		if ($result->num_rows() == 1) {
			//set session data
			$this->session->set_userdata(
				array(
				's_admin' => TRUE,
				'loggedin' => TRUE
				)
			);
			return true;
		} 
		else{
			return false;
		}
	}

	
}//end