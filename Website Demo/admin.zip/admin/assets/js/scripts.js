"use strict";

$(document).foundation();

$(document).ready(function(){
	

    var w = window.innerWidth;
    var h = window.innerHeight;
    
    $('.av-hero-section').css('height', h, 'width', w);


$(window).resize(function(){
    
    
    var w = window.innerWidth;
    var h = window.innerHeight;
    
    $('.av-hero-section').css('height', h, 'width', w);
});

	
	$(function(){
	  $.scrollIt({
	  	 scrollTime: 800  
	  });
	});
	
	

$(function(){
    
    var mainNav = $('#av-top-bar .av-main-nav');
    
    mainNav.clone().removeClass().addClass('av-mobile-nav').prependTo('#av-top-bar');
    
    $('.av-mobile-toggle').on('click', function(e){
        e.preventDefault();
        $('.av-mobile-nav').slideToggle('slow');
    });
    
    
    $('#av-top-bar .av-mobile-nav ul li a').click(function(){
        $('.av-mobile-nav').slideUp();
    });
    
    
    $(window).on('resize', function(){
        $('.av-mobile-nav').slideUp();
    });
});





$(function(){
    
  
    $('#sub2').on('click', function(){
        $('.popupbg').show();
        $('.popupindex').show();
    });


 $('#cross').on('click', function(){
        $('.popupbg').hide();
        $('.popupindex').hide();
    });
    
});


$(function(){
    
  
    $('#Subscribe').on('click', function(){
        $('.popupbg').show();
        $('.popupindex').show();
    });


 $('#cross').on('click', function(){
        $('.popupbg').hide();
        $('.popupindex').hide();
    });
    
});







$(function() {

    $(window).scroll(function(){
        var scrollTop = $(window).scrollTop();
        if(scrollTop != 0)
            $('#av-top-bar').stop().css({'background-color':'rgba(0, 0, 102, 1)'},400);
        else   
            $('#av-top-bar').stop().css({'background-color':'transparent'},400);
    });
     
    $('#av-top-bar').hover(
        function (e) {
            var scrollTop = $(window).scrollTop();
            if(scrollTop != 0){
                $('#av-top-bar').stop().css({'background-color':'rgba(0, 0, 102, 1)'},400);
            }
        },
        function (e) {
            var scrollTop = $(window).scrollTop();
            if(scrollTop != 0){
                $('#av-top-bar').stop().css({'background-color':'rgba(0, 0, 102, 1)'},400);
            }
        }
    );
});


	var w = window.innerWidth;
	
	 if (w > 580) {
		 window.sr = new scrollReveal();
	 }
	


    var loading_bar = document.querySelectorAll('.av-loading-bar');
    var i = 0;
    
    for( i = 0; i < loading_bar.length; i++){
        
        var percent = loading_bar[i].dataset.percent;
        var small = loading_bar[i].childNodes[3];
        small.innerHTML = percent + '%';
        
        var bar = loading_bar[i].childNodes[5].childNodes[1];
        bar.style.width = percent + '%';
    }


    
    
    var options = {
      useEasing : true, 
      useGrouping : true, 
      separator : ',', 
      decimal : '.' 
    }
    
    var counter = document.querySelectorAll('.av-counter');
    var i = 0;
    
    for( i = 0 ; i < counter.length; i++ ){
        
        var num = counter[i].childNodes[1].innerHTML;
        var e = counter[i].childNodes[3];
        var id = counter[i].childNodes[1];
        
        var milestone = new countUp(id, 0, num, 0, 6, options);
        milestone.start();
        
    }
	
});
